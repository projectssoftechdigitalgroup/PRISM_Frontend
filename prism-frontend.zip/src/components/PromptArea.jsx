import React from "react";
import SendIcon from "@mui/icons-material/Send";

const PromptArea = ({ theme }) => {
  return (
    <div>
      <div
        style={{
          marginTop: "220px",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          padding: "20px",
          backgroundColor: theme.palette.background.paper,
          borderRadius: "10px",
          boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
          width: "90%",

          maxWidth: "800px",
          margin: "20px auto",
        }}
      >
        <form
          style={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            width: "100%",
            gap: "10px",
          }}
        >
          <input
            type="text"
            placeholder="Type your answer here"
            style={{
              flex: 1,
              padding: "10px",
              borderRadius: "5px",
              border: `1px solid ${theme.palette.text.primary}`, // Sync with theme
              outline: "none",
              fontSize: "1rem",
              backgroundColor: theme.palette.background.default, // Sync with theme
              color: theme.palette.text.primary, // Sync with theme
            }}
          />
          <button
            type="submit"
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              padding: "10px 15px",
              borderRadius: "5px",
              border: "none",
              backgroundColor: "#E041B1",
              color: "#fff",
              cursor: "pointer",
              transition: "background-color 0.3s ease",
              fontSize: "1rem",
              "@media (max-width: 600px)": {
                padding: "8px 10px", // Adjust padding for smaller screens
                fontSize: "0.9rem", // Adjust font size for smaller screens
              },
            }}
          >
            <SendIcon />
          </button>
        </form>
      </div>
    </div>
  );
};

export default PromptArea;
