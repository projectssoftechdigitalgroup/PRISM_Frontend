import React from 'react'
import { IoArrowBackOutline } from "react-icons/io5";

const RHistory = () => {
  return (
    <>
      <IoArrowBackOutline />
      


      Will be updated tomorrow!
    </>
  )
}

export default RHistory
