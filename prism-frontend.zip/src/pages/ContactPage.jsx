import React from 'react';

const ContactPage = () => {
  return (
    <div>
      <h1>Contact Us</h1>
      <p>Feel free to reach out to us for any inquiries or support.</p>
    </div>
  );
};

export default ContactPage;
