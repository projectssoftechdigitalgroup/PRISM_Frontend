import React from 'react';

const AboutPage = () => {
  return (
    <div>
      <h1>About Us</h1>
      <p>This is the About page of the AI Interview Agent.</p>
    </div>
  );
};

export default AboutPage;
