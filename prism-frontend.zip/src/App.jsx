import React from 'react';
import AppRoute from './AppRoute/AppRoute';

const App = () => {
  return (
    <AppRoute/>
  );
};

export default App;
